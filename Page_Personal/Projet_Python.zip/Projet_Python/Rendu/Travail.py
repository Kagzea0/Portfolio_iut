# plan de dimension 30x30
# Etape 1 : 
# 	- Naissance des proies (positions aléatoire à une fréquence donnée)
# 	- Age des proies (durée de vie aléatoire donnée et exprimée en tours)
#	- Déplacement (dans une des 9 directions qui l'entourent y compris sa propre case)
#
# Etape 2 : 
#	- Reproduction (les proies donnent naissance à une nouvelle quand elles se trouvent à côté  et que la probabilité est la bonne)
#
# Etape 3 : 
# 	- Prédateurs initiaux (à partir d'un certain tour début de la partie un nombre de prédateurs est positionné aléoirement sur le terrain)
#	- Energie des prédateurs (énergie aléatoire donnée qui diminue de 1 par tour)
#       - Le prédateur gagne un certain nombre de point de vie quand il mange une proie


from tkiteasy import *
from random import choice,randint
import time
import matplotlib.pyplot as pyplt 

# ouverture de fenêtre
g = ouvrirFenetre(900,900)

r = 14 # rayon des proies/prédateurs

for y in range(0,900,30):
	g.dessinerLigne(0,y,900,y,"white")

for x in range(0,900,30):
	g.dessinerLigne(x,0,x,900,"white")

infos_proies = [] #liste où l'on va stocker les infos de chaques proies : sa position sa durée de vie
infos_prédateurs = [] #liste où l'on va stocker les infos de chaques prédateur: sa position sa durée de vie

# listes qui vont nous servir pour l'Etape 4
liste_nb_proies=[] 
liste_nb_prédateurs=[]

list_pos_possibles=[15] #les x et y minimums du centre du disque proies/prédateurs dans l'interface graphique sont égales à 15 puis vont de 30 en 30 jusqu'à 885 qui est la derbière valeur possible avant d'atteindre 900

while 885 not in list_pos_possibles: # conception de la liste des coordonnées des centres des disques proies/prédateurs
        list_pos_possibles.append(list_pos_possibles[-1] + 30)

# print(list_pos_possibles)
        
# placement des proies aléatoirement sur le plan
def proies_initiales(NPRO):
        n=0
        for i in range (NPRO): # initialisation de la liste des proies, le nombre entré en paramètre est le nombre de proies initial et choix du x et du y
                posx = choice(list_pos_possibles)
                posy = choice(list_pos_possibles)
                infos_proies.append([n,posx,posy,randint(30,50),2])
                n+=1

def prédateurs_initiales(NPRE):
        n=0
        for i in range(NPRE): # initialisation de la liste des prédateurs, le nombre entré en paramètre est le nombre de prédateurs initial et choix du x et du y
                posx = choice(list_pos_possibles)
                posy = choice(list_pos_possibles)
                infos_prédateurs.append([n,posx,posy,randint(5,20),1])
                n+=1

# Ces 2 fonctions vont nous servir pour les courbes de l'Etape 4
def nb_proies_en_vie():
        cnt = 0
        for i in range (len(infos_proies)):
                if infos_proies[i][3]>=1:
                        cnt+=1
        liste_nb_proies.append(cnt)

def nb_prédateurs_en_vie():
        cnt = 0
        for i in range (len(infos_prédateurs)):
                if infos_prédateurs[i][3]>=1:
                        cnt+=1
        liste_nb_prédateurs.append(cnt)

def programme_proies() :
        for i in range(len(infos_proies)): # parcours de la liste des proies
                if infos_proies[i][3]>0: # si la proie en question est encore en vie
                        if type(infos_proies[i][0]) == int : # à partir de la liste des proies (ligne 45), on va les faire apparaître selon leurs coordonnées
                                infos_proies[i][0] = g.dessinerDisque(infos_proies[i][1],infos_proies[i][2],r,"green")
                        depx = choice([-30,0,30]) # déplacement possible d'une proie en abscisse
                        depy = choice([-30,0,30]) # déplacement possible d'une proie en ordonnée
                        g.update()
                        g.pause(0.001)
                        for y in range(len(infos_proies)): # apparition des différents murs tout autour de l'interface graphique et condition de déplacement des proies sur une même case
                                if infos_proies[y][3]>0:
                                        if infos_proies[y][1] == infos_proies[i][1]+ depx and infos_proies[y][2] == infos_proies[i][2]+ depy : # impossibilité pour deux proies d'être sur la même case
                                                depx = 0
                                                depy = 0
                                        elif infos_proies[i][1]+ depx > 900 or infos_proies[i][2]+ depy > 900 : # murs de droite et du dessous
                                                depx = 0
                                                depy = 0
                                        elif infos_proies[i][1]+ depx < 0 or infos_proies[i][2]+ depy < 0 : # murs de gauche et du dessus
                                                depx= 0
                                                depy= 0
                        g.deplacer(infos_proies[i][0],depx,depy) #déplacement de la proie si les conditions sont respectées
                        infos_proies[i][1]+= depx # modification de la liste en fontion du déplacement des proies en x et en y
                        infos_proies[i][2]+= depy
                        for z in range(len(infos_proies)): # reproduction des proies
                                if i!=z and infos_proies[z][3]>0: # parcours de la liste hormis les proies mortes 
                                        if -30 <= infos_proies[i][1]-infos_proies[z][1]<= 30 and -30 <= infos_proies[i][2]-infos_proies[z][2]<= 30 : # si une proie est à proximité d'une autre (dans les 8 cases alentours)
                                                if infos_proies[i][4] > 0 and infos_proies[z][4] > 0 : # si elles ont la capacité de faire encore un enfant, réduction de 1 de leur nombre d'enfant encore possible
                                                        b = choice(list_pos_possibles) # coordonnées de leur enfant
                                                        c = choice(list_pos_possibles)
                                                        infos_proies[i][4]-= 1 
                                                        infos_proies[z][4]-= 1
                                                        var = True
                                                        for w in range(len(infos_proies)):
                                                                if infos_proies[w][3]>0:
                                                                        if infos_proies[w][1] == b and infos_proies[w][2] == c : # si une proie se trouve deja a cette position
                                                                                var = False
                                                        if var != False :
                                                                infos_proies.append([len(infos_proies),b,c,randint(30,50),2]) # on ajoute l'enfant a la liste
                        infos_proies[i][3]-= 1 #on enleve 1 de vie a la fin du tour
                        if infos_proies[i][3]== 0: # si elle a plus de vie elle disparait
                                g.supprimer(infos_proies[i][0])


def programme_prédateurs():
        for i in range(len(infos_prédateurs)): # parcours de la liste des prédateurs
                if infos_prédateurs[i][3]>0: #si le prédateur en question est encore en vie
                        if type(infos_prédateurs[i][0]) == int : # à partir de la liste des prédateurs, on va les faire apparaître selon leurs coordonnées
                                infos_prédateurs[i][0] = g.dessinerDisque(infos_prédateurs[i][1],infos_prédateurs[i][2],r,"red")
                        depx = choice([-30,0,30])
                        depy = choice([-30,0,30])
                        for y in range(len(infos_prédateurs)): # déplacement des prédateurs
                                if infos_prédateurs[y][1] == infos_prédateurs[i][1]+ depx and infos_prédateurs[y][2] == infos_prédateurs[i][2]+ depy :
                                        depx = 0
                                        depy = 0
                                elif infos_prédateurs[i][1]+ depx > 900 or infos_prédateurs[i][2]+ depy > 900 :
                                        depx = 0
                                        depy = 0
                                elif infos_prédateurs[i][1]+ depx < 0 or infos_prédateurs[i][2]+ depy < 0 :
                                        depx= 0
                                        depy= 0
                        g.deplacer(infos_prédateurs[i][0],depx,depy)
                        infos_prédateurs[i][1]+= depx
                        infos_prédateurs[i][2]+= depy
                        for z in range(len(infos_proies)): 
                                if infos_proies[z][3]>0 and type(infos_proies[z][0])!= int:
                                        if infos_prédateurs[i][1]==infos_proies[z][1] and infos_prédateurs[i][2]==infos_proies[z][2]: #si un prédateur et une proie se trouvent sur la même case
                                                g.supprimer(infos_proies[z][0]) #le prédateur mange la proie : la proie disparait 
                                                infos_prédateurs[i][3]+=5 # et on ajoute 5 points de vies au prédateur en question
                                                print(infos_proies[z])
                                                infos_proies[z][3]=0
                        for v in range(len(infos_prédateurs)): #reproduction des prédateurs
                                if i!=v and infos_prédateurs[v][3] > 0 :
                                        if -30 <= infos_prédateurs[i][1]-infos_prédateurs[v][1]<= 30 and -30 <= infos_prédateurs[i][2]-infos_prédateurs[v][2]<= 30 :
                                                if infos_prédateurs[i][4] > 0 and infos_prédateurs[v][4] > 0 :
                                                        b = choice(list_pos_possibles)
                                                        c = choice(list_pos_possibles)
                                                        infos_prédateurs[i][4]-= 1
                                                        infos_prédateurs[v][4]-= 1
                                                        var = True
                                                        for w in range(len(infos_prédateurs)):
                                                                if infos_prédateurs[w][3]>0:
                                                                        if infos_prédateurs[w][1] == b and infos_prédateurs[w][2] == c :
                                                                                var = False
                                                        if var != False :
                                                                infos_prédateurs.append([len(infos_prédateurs),b,c,randint(30,50),2])
                        infos_prédateurs[i][3]-=1
                        if infos_prédateurs[i][3]==0 :
                                g.supprimer(infos_prédateurs[i][0])

def programme(NPRO,NPRE,NBTOUR,NBTOUR_PRE):
        proies_initiales(NPRO)
        prédateurs_initiales(NPRE)
        for x in range(NBTOUR):
                programme_proies()
                if x >= NBTOUR_PRE :
                        programme_prédateurs()  
                nb_proies_en_vie()
                nb_prédateurs_en_vie()
        pyplt.plot(list(range(NBTOUR)),liste_nb_proies , "green")   
        pyplt.plot(list(range(NBTOUR)),liste_nb_prédateurs, "red")
        pyplt.show()


programme(randint(50,80),randint(40,60),randint(150,200),randint(30,50))
# fermeture fenêtre
g.fermerFenetre()
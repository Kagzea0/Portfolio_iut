from tkiteasy import *
from random import randint
import time; print(time.time())

# ouverture de fenêtre
g = ouvrirFenetre(900,900)

r = 10

for y in range(0,900,30):
	g.dessinerLigne(0,y,900,y,"white")

for x in range(0,900,30):
	g.dessinerLigne(x,0,x,900,"white")

infos_proies = [] #liste où l'on va stocker les infos de chaques proies : sa position et sa durée de vie
n=0

#placement des proies aléatoirement sur le plan
for i in range (10000000):
        posx = randint(0,900)
        posy = randint(0,900)
        if posx % 15 == 0 and posy % 15 == 0 and posx % 30 != 0 and posy % 30 != 0 :
                c1 = g.dessinerDisque(posx,posy,r,"green")
                infos_proies.append([n,posx,posy,randint(10,50)])
                n+=1
                input("dessiner-disque - presser ENTREE")

print(infos_proies)
                
                
while g.recupererClic() == None:
    continue
# fermeture fenêtre
g.fermerFenetre()

